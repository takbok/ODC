#!/bin/bash
HOST=0
PORT=8100

# clear other LO instances
pkill -9 soffice.bin
pkill -9 soffice

# start headless LO instance
# enforce that no Xorg server is being used(by setting the env variable)
DISPLAY=''
libreoffice \
    --nologo \
    --headless \
    --invisible \
    --nofirststartwizard \
    --accept="socket,host=$HOST,port=$PORT,tcpNoDelay=1;urp;StarOffice.ServiceManager" 2>/dev/null
