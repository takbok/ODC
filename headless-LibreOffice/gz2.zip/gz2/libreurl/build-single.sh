#!/bin/bash
LPATH="/usr/lib/ure/lib:/usr/lib/libreoffice/program/"
# to skip tests add -Dmaven.test.skip=true
mvn clean package -DargLine="-Djava.library.path=$LPATH" $@
