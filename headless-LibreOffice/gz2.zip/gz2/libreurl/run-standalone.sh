#!/bin/bash
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/usr/lib/ure/lib/"
CPATH="target/lib/*:target/*"
LPATH="/usr/lib/ure/lib:/usr/lib/libreoffice/program/"
java -cp $CPATH -Djava.library.path=$LPATH com.libre.util.App $@

