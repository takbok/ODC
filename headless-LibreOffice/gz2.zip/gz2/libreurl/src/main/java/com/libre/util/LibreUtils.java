/*
 * This is a helper class with functionality to control LibreOffice
 */

package com.libre.util;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.tuple.*;

import com.sun.star.comp.helper.Bootstrap;
import com.sun.star.connection.XConnection;
import com.sun.star.connection.XConnector;
import com.sun.star.uno.AnyConverter;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XEnumeration;
import com.sun.star.container.XEnumerationAccess;
import com.sun.star.container.XIndexAccess;
import com.sun.star.container.XIndexReplace;
import com.sun.star.container.XNameAccess;
import com.sun.star.container.XNameContainer;
import com.sun.star.container.XNamed;
import com.sun.star.document.XEventListener;
import com.sun.star.document.XStorageBasedDocument;
import com.sun.star.document.XViewDataSupplier;
import com.sun.star.embed.XRelationshipAccess;
import com.sun.star.embed.XStorage;
import com.sun.star.text.TextColumn;
import com.sun.star.text.TextContentAnchorType;
import com.sun.star.text.XFootnote;
import com.sun.star.text.XFootnotesSupplier;
import com.sun.star.text.XPageCursor;
import com.sun.star.text.XParagraphCursor;
import com.sun.star.text.XSentenceCursor;
import com.sun.star.text.XSimpleText;
import com.sun.star.text.XText;
import com.sun.star.text.XTextCursor;
import com.sun.star.text.XTextDocument;
import com.sun.star.text.XTextFieldsSupplier;
import com.sun.star.text.XTextRange;
import com.sun.star.text.XWordCursor;
import com.sun.star.uno.XComponentContext;
import com.sun.star.lang.IllegalArgumentException;
import com.sun.star.lang.IndexOutOfBoundsException;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XComponent;
import com.sun.star.frame.XComponentLoader;
import com.sun.star.frame.XStorable;
import com.sun.star.io.IOException;
import com.sun.star.io.XStream;
import com.sun.star.util.XRefreshable;
import com.sun.star.util.XSearchDescriptor;
import com.sun.star.util.XSearchable;
import com.sun.star.lang.XMultiComponentFactory;
import com.sun.star.text.XTextField;
// all of these come from unoil.jar
import com.sun.star.lang.XMultiServiceFactory;
import com.sun.star.awt.Point;
import com.sun.star.beans.Property;
import com.sun.star.beans.PropertyValue;
import com.sun.star.beans.StringPair;
import com.sun.star.beans.UnknownPropertyException;
import com.sun.star.beans.XPropertySet;
import com.sun.star.beans.XPropertySetInfo;
import com.sun.star.bridge.UnoUrlResolver;
import com.sun.star.bridge.XBridge;
import com.sun.star.bridge.XBridgeFactory;
import com.sun.star.bridge.XUnoUrlResolver;
import com.sun.star.util.CloseVetoException;
import com.sun.star.util.Date;
import com.sun.star.util.DateTime;
import com.sun.star.util.XCloseable;
import com.sun.star.view.XSelectionSupplier;
import com.sun.star.util.XPropertyReplace;
/*
 * required by updateDocument
 */
import com.sun.star.lang.XServiceInfo;

/*
 * for XPageCursor
 */
import com.sun.star.frame.XModel;
import com.sun.star.text.XTextViewCursor;
import com.sun.star.text.XTextViewCursorSupplier;
import com.sun.star.frame.XController;

/*
 * inserting page break
 */
import com.sun.star.style.BreakType;
import com.sun.star.text.ControlCharacter;

import com.opencsv.CSVWriter;

public class LibreUtils {

	private static AtomicInteger bridgeIndex = new AtomicInteger();

	XComponentLoader xCLoader = null;
	XTextDocument xDoc = null;
	XComponent xComp = null;
	XComponentContext xContext = null;
	XComponentContext xRemoteContext = null;
	XText xText = null;
	XTextCursor xTCursor = null;
	XConnection xConnection = null;
	XBridge xBridge = null;
	XMultiServiceFactory mxServiceManager = null;
	XModel xModel = null;
	XController xController = null;
	XTextViewCursorSupplier xViewCursorSupplier = null;
	XTextViewCursor xViewCursor = null;
	XViewDataSupplier xViewDataSupplier = null;
	XFootnotesSupplier xFootnotesSupplier = null;
	public XComponent bridgeComponent;
	private XMultiComponentFactory serviceManager;
	private XComponentContext componentContext;

	/*
	 * This is used to cast objects using UnoRuntime.
	 * 
	 * Example: ClassName object = OfficeUtils.cast(ClassName.class,
	 * otherTypeObject);
	 * 
	 */
	public static <T> T unoCast(Class<T> type, Object object) {
		return (T) UnoRuntime.queryInterface(type, object);
	}

	/*
	 * Opens an instance of LibreOffice Writer then opens a file. If null is
	 * given as argument for the file path, then it creates an empty document.
	 *
	 */
	public void openInstanceWriter(com.sun.star.uno.XComponentContext xContext, String filePath) {
		try {
			// get the remote office service manager
			XMultiComponentFactory xMCF = (XMultiComponentFactory) xContext.getServiceManager();

			Object oDesktop = xMCF.createInstanceWithContext("com.sun.star.frame.Desktop", xContext);

			xCLoader = (XComponentLoader) UnoRuntime.queryInterface(com.sun.star.frame.XComponentLoader.class,
					oDesktop);
			com.sun.star.beans.PropertyValue[] szEmptyArgs = new com.sun.star.beans.PropertyValue[0];

			String strDoc = null;
			if (filePath == null) {
				strDoc = "private:factory/swriter";
			} else {
				strDoc = "file://" + filePath;
			}

			xComp = xCLoader.loadComponentFromURL(strDoc, "_blank", 0, szEmptyArgs);
			xDoc = (XTextDocument) UnoRuntime.queryInterface(com.sun.star.text.XTextDocument.class, xComp);

			// getting the text object
			xText = xDoc.getText();
			// create a cursor object
			xTCursor = xText.createTextCursor();

			xModel = UnoRuntime.queryInterface(XModel.class, xComp);
			xController = xModel.getCurrentController();
			xViewCursorSupplier = UnoRuntime.queryInterface(XTextViewCursorSupplier.class, xController);
			xViewCursor = xViewCursorSupplier.getViewCursor();
			xViewDataSupplier = unoCast(XViewDataSupplier.class, xModel );
			xFootnotesSupplier = unoCast(XFootnotesSupplier.class, xDoc);

		} catch (Exception e) {
			System.err.println("[ERROR] Exception thrown while trying to create new instance of LO Writer");
			e.printStackTrace(System.err);
			System.exit(11);
		}
	}

	public XPageCursor getXPageCursorInstance() {
		XPageCursor xPageCursor = unoCast(XPageCursor.class, xViewCursor);
		return xPageCursor;
	}
	
	
	/*
	 * This method will first get a list of all textranges that have
	 * a certain property("HyperLinkURL") then it will iterate over all
	 * of them, it will position the pagecursor over each one, and it will
	 * extract the url and the page number for each of them. 
	 *
	 */
	public ArrayList<Pair<String, Integer>> extractMainLinks() {
		ArrayList<Pair<String, Integer>> linkPageArr = new ArrayList<Pair<String, Integer>>();

		XSearchable xSearchable = (XSearchable) UnoRuntime.queryInterface(XSearchable.class, xDoc);

		XSearchDescriptor xSearchDescriptor = xSearchable.createSearchDescriptor();

		XPropertyReplace xPropertyReplace = (XPropertyReplace) UnoRuntime.queryInterface(XPropertyReplace.class,
				xSearchDescriptor);
		xPropertyReplace.setValueSearch(false);

		PropertyValue[] aSearchAttrs = new PropertyValue[1];
		aSearchAttrs[0] = new PropertyValue();
		aSearchAttrs[0].Name = "HyperLinkURL";

		try {
			xPropertyReplace.setSearchAttributes(aSearchAttrs);
		} catch (Exception e) {
			e.printStackTrace();
		}
		XPageCursor xPageCursor = getXPageCursorInstance();
		XIndexAccess xTextRanges = xSearchable.findAll(xSearchDescriptor);


		for (int i = 0; i < xTextRanges.getCount(); i++) {
			XTextRange xTextRange;
			try {
				xTextRange = (XTextRange) UnoRuntime.queryInterface(XTextRange.class, xTextRanges.getByIndex(i));
				XPropertySet xPropertySet = (XPropertySet) UnoRuntime.queryInterface(XPropertySet.class, xTextRange);
				if (xTextRange != null && xPropertySet != null) {

					String sHyperLinkURL = AnyConverter.toString(xPropertySet.getPropertyValue("HyperLinkURL"));
					/*
					 * Skip internal links or anchors, and focus on actual
					 * http-links (because the page cursor takes time to reposition)
					 */
					if (!sHyperLinkURL.toLowerCase().startsWith("http")) {
						continue;
					}
					xViewCursor.gotoRange(xTextRange, false);
					int pageNum = xPageCursor.getPage();
					/*
					 * Store link and the page number it was found on.
					 */
					MutablePair<String, Integer> newPair = new MutablePair<String, Integer>(sHyperLinkURL, pageNum);
					linkPageArr.add(newPair);
				}
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		return linkPageArr;
	}
	
	
	/*
	 * This is a fallback method for extracting only the footnote links
	 * out of the document. It's not in use at this point in time.
	 * 
	 */
	public ArrayList<Pair<String, Integer>> extractFootnoteLinks()  {
		ArrayList<Pair<String, Integer>> allFootnoteLinks = new ArrayList<Pair<String, Integer>>();
		XIndexAccess xFootnotes = unoCast(XIndexAccess.class, xFootnotesSupplier.getFootnotes());
		int footnoteCount = xFootnotes.getCount();
		
		XPageCursor xPageCursor = getXPageCursorInstance();
		for(int i = 0; i < footnoteCount ; i++) {
			XFootnote xFootnote;
			
			try {
				xFootnote = unoCast(XFootnote.class, xFootnotes.getByIndex(i));
			} catch (Exception e) {
				e.printStackTrace();
				continue;
			}
			
			XSimpleText xSimple = (XSimpleText ) UnoRuntime.queryInterface (
					XSimpleText.class, xFootnote );
			
			XText footnoteXText = unoCast(XText.class, xSimple);
			
			xViewCursor.gotoRange(footnoteXText.getStart(), false);
			int pageNum = xPageCursor.getPage();
			/*
			 * Skip if the footnote object is null
			 */
			if(footnoteXText == null) {
				continue;
			}
			/*
			 * Retrieve the text of the footnote (including the links)
			 */
			String footnoteString = footnoteXText.getString().toString();
			ArrayList<String> footnoteLinks = new ArrayList(); 
			String linkExtractionRegex = "(https?://\\S+|www\\.\\S+)";
			Pattern p = Pattern.compile(linkExtractionRegex,
					Pattern.CASE_INSENSITIVE |
					Pattern.MULTILINE |
					Pattern.DOTALL
					);

			Matcher m = p.matcher(footnoteString);
			while(m.find()) {
				String linkFound = m.group();
				MutablePair<String, Integer> newPair = new MutablePair<String, Integer>(linkFound, pageNum);
				allFootnoteLinks.add(newPair);
			}
		}
		return allFootnoteLinks;
	}
	
	/*
	 * Extract the links in the document.
	 */
	public ArrayList<Pair<String, Integer>> extractLinks()  {
		ArrayList<Pair<String, Integer>> allPairs = new ArrayList<Pair<String, Integer>>();
		ArrayList<Pair<String, Integer>> mainPairs = extractMainLinks();
		allPairs.addAll(mainPairs);
		
		/* 
		 * Currently extractFootnoteLinks is a fallback, and is not to be used,
		 * so the following code is commented:
		 * 
		 * ArrayList<Pair<String, Integer>> footnotePairs = extractFootnoteLinks();
		 * allPairs.addAll(footnotePairs);
		 */

		
		/*
		 * Sort all links by increasing page number
		 */
		Collections.sort(allPairs, Comparator.comparing(p -> p.getRight()));
		
		return allPairs;
	}

	public void writeCSVOutput(String filePath, ArrayList<Pair<String, Integer>> pageLinkPairs)
			throws java.io.IOException {
		char csvSeparator = ',';
		CSVWriter writer = new CSVWriter(new FileWriter(filePath), csvSeparator);

		for (int i = 0; i < pageLinkPairs.size(); i++) {
			Pair<String, Integer> pair = pageLinkPairs.get(i);
			String[] newRow = { pair.getLeft(), Integer.toString(pair.getRight()) };
			writer.writeNext(newRow);
		}

		writer.close();
	}

	public void closeRemoteContext() throws IOException {
		try {
			closeDoc();
			xConnection.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*
	 * This method connects to a headless instance of Libreoffice.
	 */
	public void openRemoteContext(com.sun.star.uno.XComponentContext xContext, String host, String port,
			String filePath) {

		final String socketURL = String.format("socket,host=%s,port=%s,tcpNoDelay=1", // ;urp;StarOffice.ServiceManager",
				host, port);
		try {
			System.out.println("[INFO] connection string -> " + socketURL);
			XComponentContext xLocalContext = Bootstrap.createInitialComponentContext(null);
			XMultiComponentFactory localServiceManager = xLocalContext.getServiceManager();
			XConnector connector = unoCast(XConnector.class,
					localServiceManager.createInstanceWithContext("com.sun.star.connection.Connector", xLocalContext));

			xConnection = connector.connect(socketURL);
			XBridgeFactory bridgeFactory = unoCast(XBridgeFactory.class,
					localServiceManager.createInstanceWithContext("com.sun.star.bridge.BridgeFactory", xLocalContext));
			/*
			 * uniquely identify the bridge using an index
			 */
			String bridgeName = "libreUrl" + bridgeIndex.getAndIncrement();
			xBridge = bridgeFactory.createBridge(bridgeName, "urp", xConnection, null);
			bridgeComponent = unoCast(XComponent.class, xBridge);
			serviceManager = unoCast(XMultiComponentFactory.class, xBridge.getInstance("StarOffice.ServiceManager"));
			XPropertySet properties = unoCast(XPropertySet.class, serviceManager);
			xRemoteContext = unoCast(XComponentContext.class, properties.getPropertyValue("DefaultContext"));
			System.out.println("[INFO] Opened headless LibreOffice connection");

		} catch (Exception e) {
			System.err.println("[ERROR] Libre-Url was not able to connect to LibreOffice");
			System.exit(5);
		}

	}

	/*
	 * Refresh the document
	 */
	public void refreshDocument() {

		XRefreshable xRefresh = (XRefreshable) UnoRuntime.queryInterface(XRefreshable.class, xDoc);
		xRefresh.refresh();
	}

	public void sleep(int delay) {
		try {
			Thread.sleep(delay);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}

	/*
	 * Gets the xContext and stores it in a private attribute of this class.
	 * Returns the xContext
	 */
	public XComponentContext getXContext() {
		if (xContext != null)
			return xContext;

		try {
			/*
			 * This will get the remote office component context
			 */
			xContext = com.sun.star.comp.helper.Bootstrap.bootstrap();
			if (xContext != null)
				System.err.println("[INFO] Connected to a running LibreOffice instance ...");
		} catch (Exception e) {
			e.printStackTrace(System.err);
			System.exit(1);
		}
		return xContext;
	}

	public LibreUtils() {
	}

	public void closeDoc() {
		XCloseable xcloseable = unoCast(XCloseable.class, xDoc);
		try {
			xcloseable.close(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @return the xText
	 */
	public com.sun.star.text.XText getxText() {
		return xText;
	}

	/**
	 * @return the xTCursor
	 */
	public com.sun.star.text.XTextCursor getxTCursor() {
		return xTCursor;
	}

	/**
	 * @return the xModel
	 */
	public XModel getxModel() {
		return xModel;
	}


}
