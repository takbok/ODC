package com.libre.util;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;

import junit.framework.TestCase;

import com.libre.util.LibreUtils;
import com.sun.star.io.IOException;
import com.sun.star.uno.XComponentContext;

/*
 *  Run this with:
 *  
 *      LD_LIBRARY_PATH=/usr/lib/ure/lib/ mvn clean compile test -Dtest=LibreUtilsTest -DargLine="-Djava.library.path=/usr/lib/ure/lib:/usr/lib/libreoffice/program/"
 *
 *
 * Reminder: the setUp() and tearDown()
 * 			 methods are called for each individual test method
 * (this is JUnit convention)
 */
public class LibreUtilsTest extends TestCase {
	String TEST_SOCK_PORT = "8203";
	String TEST_SOCK_HOST = "0";
	XComponentContext xContext;
	XComponentContext xRemoteContext;
	LibreUtils loh = new LibreUtils();

	private Thread threadLibre = null;

	/* TODO: need to check if soffice is present */
	public void setUp() throws Exception {
		threadLibre = new Thread(new Runnable() {
			public void run() {
				/* 
				 * enforce that libreoffice instance does not use Xorg
				 * by setting the displaynumber environment variable to
				 * an empty value
				 */
				List<String> envList = new ArrayList<String>();
				envList.add("DISPLAY=''");
				
				List<String> commandList = new ArrayList<String>();
				commandList.add("/usr/bin/soffice");
				commandList.add("-headless");
				commandList.add("-nologo");
				commandList.add("-nodefault");
				commandList.add(String.format("-accept=socket,host=%s,port=%s;urp;", TEST_SOCK_HOST, TEST_SOCK_PORT));
				String[] commandArr = commandList.toArray(new String[0]);
				String[] envArr = envList.toArray(new String[0]); 

				Process process = null;
				System.out.println("Starting libreoffice..");
				try {
					process = Runtime.getRuntime().exec(commandArr, envArr);
				} catch (Exception e) {
					e.printStackTrace();
					System.exit(-1);
				}

				/*
				 * Thread will be idle. It stays open so the subprocess that
				 * runs libreoffice can also stay open.
				 */
				while (true) {
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						System.err.println("LibreOffice thread finished");
						break;
					}
				}

				process.destroy();
			}
		});

		threadLibre.start();
		/*
		 * wait for LibreOffice to start
		 */
		Thread.sleep(1400);
	}
	
	
	public ArrayList<Pair<String, Integer>> extractData(String filePath) {
		File testFile = new File(filePath);
		String testPath = testFile.getAbsolutePath();

		xContext = loh.getXContext();
		loh.openRemoteContext(xContext, TEST_SOCK_HOST, TEST_SOCK_PORT, "");
		xRemoteContext = loh.xRemoteContext;
		if (xRemoteContext == null) {
			fail("Unable to acquire remote context");
		}
		loh.openInstanceWriter(xRemoteContext, testPath);
		loh.refreshDocument();
		ArrayList<Pair<String, Integer>> pairs = loh.extractLinks();
		return pairs;
	}
	
	/*
	 * This test extracts links from a simple docx document
	 * and checks the number of links found and the value of the
	 * first link found.
	 */
	public void testBasicDocument() throws Exception {
		ArrayList<Pair<String, Integer>> pairs = extractData("docs/Office365MidsizeBusinessQuickDeploymentGuide.docx");
		assertEquals("docx file has 9 links", pairs.size(), 9);
		assertEquals("correct first link", pairs.get(0).getLeft(), "http://go.microsoft.com/fwlink/p/?LinkId=324277");
	}
	
	/*
	 * We are testing the extraction of links from a document containing
	 * them in the footnotes (as well as the main text).
	 * 
	 * Since on two different LO versions the pagenum of links was found to be different,
	 * this is not tested here.
	 */
	public void testFootnoteDocument() throws Exception {
		ArrayList<Pair<String, Integer>> pairs = extractData("docs/a.docx");
		
		for (int i = 0; i < pairs.size(); i++) {
			System.out.println(pairs.get(i).toString());
		}
		
		assertEquals("1st link","http://www.ldonline.org/article/22725/?theme=print",pairs.get(0).getLeft());
		assertEquals("2nd link","http://www.doe.virginia.gov/special_ed/regulations/state/regs_speced_disability_va.pdf",pairs.get(1).getLeft());
		assertEquals("13 links found in document with footnotes", pairs.size(), 13);
	}

	public void tearDown() {
		/*
		 * close the thread
		 */
		System.err.println("tearDown of test environment");
		try {
			loh.closeRemoteContext();
		} catch (Exception e) {
			e.printStackTrace();
		}
		threadLibre.interrupt();
	}

}
