package com.libre.util;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.OptionBuilder;
import com.libre.util.LibreUtils;
import com.sun.star.uno.XComponentContext;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang3.tuple.*;
/*
 * See the scripts
 * - run-single.sh
 * - run-standalone.sh
 * for running this program.
 * 
 * Reported bugs:
 * 
 * - https://bugs.documentfoundation.org/show_bug.cgi?id=99997
 * - https://bugs.documentfoundation.org/show_bug.cgi?id=99988
 * 
 */

public class App {

	public void throwsException() {
		throw new UnsupportedOperationException();
	}
	
	
	public static boolean hasValidFileSignature(String filePath) throws IOException {
		/*
		 * This function checks if the file has a known .docx signature.
		 * 
		 * reference: https://en.wikipedia.org/wiki/List_of_file_signatures 
		 * - 50 4B 05 06
		 * - 50 4B 07 08
		 * 
		 * 
		 * 
		 * reference: http://www.garykessler.net/library/file_sigs.html 
		 * - 50 4B 03 04 14 00 06 00
		 * - D0 CF 11 E0 A1 B1 1A E1
		 * 
		 * reference: (found manually while testing with libreoffice-saved docx files)
		 * - 50 4b 03 04 14 00 08 08
		 */

		ArrayList<String> docxSigs = new ArrayList<>(
				Arrays.asList("504b0506", "504b0708", "504b030414000600", "d0cf11e0a1b11ae1","504b030414000808"));

		/*
		 * Read first bytes of file data to check if it is the expected filetype
		 */

		File file = new File(filePath);
		if (file.length() < 8) {
			/*
			 * The file was too short to check the signature and too small to
			 * have any contents
			 */
			return false;
		}

		byte[] fileData = new byte[8];
		DataInputStream dis = new DataInputStream(new FileInputStream(file));
		int bytesRead = dis.read(fileData, 0, 8);
		dis.close();

		boolean matchedSig = false;

		/*
		 * Run through known sigs and check if the file matches any of them
		 */
		for (String sig : docxSigs) {
			/*
			 * Load next signature and initialize matched boolean to true
			 */
			byte[] sigBytes = new BigInteger(sig, 16).toByteArray();
			matchedSig = true;
			for (int i = 0; i < sigBytes.length - 1; i++) {
				matchedSig &= (fileData[i] == sigBytes[i]);
			}
			;
			/*
			 * Exit early if we matched one signature
			 */
			if (matchedSig)
				break;
		}

		return matchedSig;
	}

	public static HashMap<String, String> parseCmdLineParams(String[] args) throws ParseException, IOException {
		HashMap<String, String> cmdLineParams = new HashMap<String, String>();

		CommandLineParser parser = new PosixParser();
		Options options = new Options();
		options.addOption(OptionBuilder.withLongOpt("doc-path").hasArg(true)
				.withDescription("path to the document that is going to be annotated").create('d'));
		options.addOption(OptionBuilder.withLongOpt("output").hasArg(true)
				.withDescription("path to the output csv file").create('o'));

		HelpFormatter formatter = new HelpFormatter();

		CommandLine line = parser.parse(options, args);
		String docPath = new String();
		String outputPath = new String();

		if (line.hasOption("doc-path")) {
			docPath = line.getOptionValue("doc-path");
			// System.out.println("docPath="+docPath);
			File fileDocPath = new File(docPath);
			if (!(fileDocPath).exists()) {
				System.err.println("[ERROR] Parameter doc-path points to a file that doesn't exist");
				System.exit(3);
			}
			if (!hasValidFileSignature(docPath)) {
				System.err.println("[ERROR] The doc-path argument does not point to a valid .docx file");
				System.exit(6);
			}
			cmdLineParams.put("doc-path", fileDocPath.getAbsolutePath());
		} else {
			System.err.println("[ERROR] The doc-path parameter is required");
			formatter.printHelp("libreurl", options);
			System.exit(2);
		}

		if (!line.hasOption("output")) {
			/*
			 * If you don't specify an output path, it will be written in
			 * a file called "output.csv"
			 */
			outputPath = (new File("output.csv")).getAbsoluteFile().getPath();
			System.err.println("outputPath = " + outputPath);
			cmdLineParams.put("output", outputPath);
		} else {
			outputPath = line.getOptionValue("output");
			File fileOutput = new File(outputPath).getAbsoluteFile();
			if (!fileOutput.getParentFile().exists()) {
				System.err.println("[ERROR] The parent directory of the output file doesn't exist");
				System.exit(9);
			}
			cmdLineParams.put("output", outputPath);
		}

		return cmdLineParams;
	}

	public static void main(String[] args) throws Exception {
		HashMap<String, String> cmdLineParams = parseCmdLineParams(args);
		LibreUtils loh = new LibreUtils();
		XComponentContext xContext = loh.getXContext();
		loh.openRemoteContext(xContext, "0", "8100", "");
		XComponentContext xRemoteContext = loh.xRemoteContext;
		loh.openInstanceWriter(xRemoteContext, cmdLineParams.get("doc-path"));
		/* 
		 * The refresh statement is run here(before traversing the document) because
		 * if it's not then:
		 * a) the page numbers will be incorrect
		 * b) the extraction logic won't be able to fetch footnote links
		 * 
		 * (maybe it has to do with a not-yet-ready OO/LO's internal state, although not
		 * specifically mentioned in the official LO docs).
		 * See bug 99997 reported to LibreOffice.
		 */
		loh.refreshDocument();
		ArrayList<Pair<String, Integer>> pairs = loh.extractLinks();
		loh.writeCSVOutput(cmdLineParams.get("output"), pairs);
		loh.closeRemoteContext();
		/* Exit with status-code zero. */
		System.exit(0);
	}
}
