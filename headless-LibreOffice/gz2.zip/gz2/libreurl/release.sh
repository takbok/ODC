#!/bin/bash
DIR="/tmp/release-libre-url"
ARC="/tmp/libre-url.tar.gz"
rm -rf $DIR $ARC target/
./build-standalone.sh
mkdir -p $DIR
mkdir -p $DIR/manual/
cp manual/manual.html manual/manual.pdf manual/*.jpg $DIR/manual/
cp -r target/ $DIR/
cp run-standalone.sh $DIR/libre-url
cp libre-headless.sh $DIR/libre-headless
cp docs/Office365MidsizeBusinessQuickDeploymentGuide.docx $DIR/sample.docx
pushd .
cd $(dirname $DIR)
tar czvf $(basename $ARC) $(basename $DIR)
popd
