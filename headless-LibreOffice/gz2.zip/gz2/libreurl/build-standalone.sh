#!/bin/bash
CPATH="target/lib/*:target/libre-util-1.0-SNAPSHOT.jar"
LPATH="/usr/lib/ure/lib:/usr/lib/libreoffice/program/"
LD_LIBRARY_PATH=/usr/lib/libreoffice/program/ \
    mvn clean package assembly:single \
    -DargLine="-Djava.library.path=$LPATH" $@
    
