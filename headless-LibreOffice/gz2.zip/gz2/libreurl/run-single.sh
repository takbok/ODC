#!/bin/bash
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/usr/lib/ure/lib/"
LPATH="/usr/lib/ure/lib:/usr/lib/libreoffice/program/"
CPATH="target/lib/*:target/*"
java -classpath $CPATH -Djava.library.path=$LPATH com.libre.util.App $@

